# FOSS and Open Engineering — Project Philosophy

## Source availability is not enough

Publishing a repository is valuable, but a public codebase alone does not necessarily make a project understandable or meaningfully participatory.

A contributor still needs to know:

- what problem is being solved
- why the system is designed this way
- what assumptions the design depends on
- what alternatives were rejected
- which strange-looking implementation choices are intentional
- which invariants must never be broken
- how a proposed change is validated
- where the system can safely be extended

Without that context, open source can degrade into:

> **a consumer application with a pull-request button.**

## Stronger definition of openness

Shrek should aim to expose not only the implementation, but enough engineering context that another person can safely understand, modify, critique, and extend it.

The public project should preserve several layers:

```text
CODE
what exists

TESTS
what must remain true

ARCHITECTURE
how the pieces fit

DECISIONS
why they fit that way

LESSONS
what failed and what was learned

HISTORY
how the design evolved
```

## Why this matters for Shrek

Many security decisions are not obvious from code alone.

Example:

A future contributor might see a T2 rootfs copied into tmpfs and decide:

> This is wasteful. Let's optimize it away.

Without context, that looks reasonable.

But the implementation exists because the sealed dm-verity rootfs exposed a real incompatibility: gVisor's gofer needed to create host-side bind-mount destinations inside the rootfs tree. Direct use of the read-only rootfs failed with `EROFS`; guest-side overlay did not solve the host-side mutation requirement.

The "weird" code therefore represents a learned invariant.

Good open engineering should make that discoverable before someone accidentally reintroduces the failure.

## FOSS as distributed expertise

No single maintainer needs to be the world expert in:

- kernel security
- formal methods
- networking
- systemd
- virtualization
- supply-chain security
- desktop UX
- AI systems

A strong FOSS project makes its architecture legible enough that specialists can challenge the parts they know deeply.

The desired posture is:

> Here is the code, threat model, invariants, decisions, tests, architecture map, and reasoning behind the strange parts. Tear it apart.

Finding a flaw is the project working as intended.

## Open engineering, not personality cult

The project should not depend on the original author's brain remaining the only source of context.

A contributor should be able to trace:

```text
"I want to change T2 rootfs handling."

        ↓

current implementation
        ↓
security invariant
        ↓
design decision
        ↓
previous failed approach
        ↓
acceptance tests
        ↓
files likely affected
```

The project becomes easier to maintain when knowledge is attached to the engineering artifact rather than only to the original developer.
