# Project Intelligence for AI-Assisted FOSS Development

## Problem

AI-heavy development currently has an expensive and repetitive knowledge problem.

Engineer A clones a repository.

Their agent begins almost from zero:

```text
grep
read
grep
read
infer architecture
misunderstand a relationship
read more
build temporary context
```

Engineer B joins later with a different agent and repeats the same archaeology.

The repository has shared source code and shared Git history, but the agents do not necessarily begin with a shared machine-navigable understanding of the project.

## Proposed direction

Ship a **machine-readable indexed project graph** alongside the FOSS project.

Graphify can be used to generate the initial codebase graph.

The graph is not canonical truth.

It is a navigation and context-compression layer over canonical source, tests, and architecture documents.

Conceptually:

```text
source code
   +
project docs
   ↓
Graphify / project indexer
   ↓
machine-readable project graph
   ↓
Claude / Codex / local LLM / Donkey / IDE tools
```

An agent can ask:

```text
"What implements T2 isolation?"
```

and receive a scoped neighborhood:

```text
T2
├── shrek-policy
├── gatekeeperd
├── t2_plane.rs
├── runsc
├── gvisor.pin
├── isolation.md
└── T2 proof gates
```

It then reads the authoritative source required for its task.

This is **context retrieval for development**, not context stuffing.

## Why ship the graph

The graph should be FOSS because it is part of making the project understandable to AI-assisted contributors.

Traditional collaborative development ships:

```text
source
README
docs
tests
issues
git history
```

AI-heavy collaborative development can additionally ship:

```text
project knowledge graph
agent-query interface
architecture relationships
invariant / test relationships
```

This lets the project carry part of its own machine-readable understanding.

## Important boundary

The public graph is generated from the public project.

Private personal memory systems are not part of the shipped artifact.

A maintainer may use private tools or memories while authoring documentation, reconstructing decisions, or preserving lessons.

Those remain private.

Only reviewed project knowledge should become public documentation or project metadata.

## Evidence hierarchy

Suggested hierarchy:

```text
CURRENT SOURCE
+
TESTS / SEALED POLICY
        │
        │ authoritative implementation
        ▼

ARCHITECTURE / ADRs
        │
        │ declared design intent
        ▼

PROJECT GRAPH
        │
        │ structural navigation / context compression
        ▼

LLM
interpretation / synthesis
```

If the graph disagrees with current source, source wins.

If an inferred edge is used for an important security claim, the agent should verify it against source and tests before stating it as fact.

## Graph-assisted documentation workflow

```text
repo
 ↓
Graphify
 ↓
graph.json
 ↓
LLM asks for relevant subgraph
 ↓
LLM selectively reads authoritative files
 ↓
developer documentation
```

This is more efficient than repeatedly asking an LLM to reread an entire operating-system repository.

The graph helps the model identify the small set of files that actually matter for a documentation page.

## Documentation impact analysis

Longer-term workflow:

```text
git changes
    ↓
incremental graph rebuild
    ↓
changed graph neighborhoods
    ↓
docs impact analysis
    ↓
pages / invariants potentially affected
    ↓
LLM drafts updates
    ↓
human review
```

A pull request could eventually expose:

```text
code diff
graph diff
affected architecture areas
affected documentation
affected invariants / gates
```

## Relationship to Shrek OS

The shared project graph and Shrek's security architecture address two different problems encountered in practical AI development.

### Knowledge problem

> Why does every fresh agent/session have to rediscover what the software is?

Response:

> Shared indexed project intelligence.

### Authority problem

> Why does an AI need ambient access to the developer's whole desktop session just to work on a project?

Response:

> Explicit machine-enforced capabilities and graduated isolation.

Together:

```text
                AI DEVELOPMENT

          KNOWLEDGE              AUTHORITY
              │                      │
              ▼                      ▼
     project intelligence      Shrek capabilities
      graph + project docs     isolation + policy
              │                      │
              └─────────┬────────────┘
                        ↓
                    coding agent
```

A concise formulation:

> **Give the agent better knowledge while giving it less ambient authority.**

## Broader idea

Git provides shared history of changes.

Documentation provides shared human explanation.

A project knowledge graph can provide AI-assisted teams with a shared machine-navigable model of the codebase.

That is a natural evolution of collaborative development for projects increasingly built with agents.
