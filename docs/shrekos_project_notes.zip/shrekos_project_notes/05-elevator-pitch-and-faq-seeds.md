# Elevator Pitch and FAQ Seeds

## Elevator pitch

**Shrek OS is a Linux system built for people who are increasingly letting AI work directly on their computers.**

AI coding agents can already edit repositories, run commands, compile code, search files, browse documentation, and operate semi-autonomously. Today, much of their safety still depends on natural-language instructions such as "stay inside this repo" or "don't read private files."

Those instructions usually work. The problem is that **usually is not a security model**.

Shrek keeps natural language for intent and workflow, but moves authority underneath the model. Filesystem access, network access, execution privileges, resource limits, and isolation levels are granted explicitly and enforced by deterministic policy and Linux security primitives.

The goal is not to make AI perfectly trustworthy.

The goal is to make an occasional AI mistake **boring instead of catastrophic**.

## Short version

> **Human language tells the agent what it should do. Shrek decides what it can do.**

## Another short version

> **Give the agent enough of the computer to do the job, not enough of the computer to become the computer.**

## FAQ / skeptical questions to answer

- How is this different from just running Claude Code or Codex in a terminal?
- Why not just use Docker?
- Why not use a VM?
- Why does this need to be an operating system?
- Can the runtime work on Debian, Fedora, or Arch?
- What guarantees are weaker outside Shrek OS?
- What happens if the model forgets a rule?
- What happens if the model gets prompt-injected?
- Can an agent access my SSH keys?
- Can it inspect another project?
- Can it upload my source code to arbitrary servers?
- How granular is network access?
- Who decides whether a workload is trusted?
- Can the agent lower its own isolation tier?
- What happens if the required sandbox cannot be created?
- Why use multiple isolation technologies?
- Is AI involved in security decisions?
- What is deterministic?
- What is probabilistic?
- What is Swamp?
- Why not use a database as the filesystem?
- Can semantic search leak data the agent cannot directly read?
- Does Shrek work without Donkey?
- Is this still useful as normal Linux?
- What overhead does isolation add?
- Am I going to fight permission prompts constantly?
- What is the smallest demo that proves the model is useful?

## Strong demo idea

Use a repository containing malicious or conflicting instructions that attempt to make an agent:

1. read `~/.ssh`
2. inspect an unrelated private project
3. send data to an unauthorized destination

Allow the model to be manipulated.

Show the agent attempting the actions.

Show the OS denying them while legitimate work inside the authorized repository remains possible.

The point is not:

> "Look, the model resisted prompt injection."

The point is:

> **"The model failed, and the security boundary still worked."**
