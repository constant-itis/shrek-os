# Shrek OS Documentation Site — Working Plan

## Goal

The documentation should support three depths of understanding.

### Level 1 — Orientation

For someone asking:

> What the hell is Shrek OS?

Content:

- project thesis
- intended audience
- why agent security belongs below the LLM
- quick architecture overview
- current project status
- install / try / demo path when available

### Level 2 — Architecture

For someone asking:

> How does this thing actually fit together?

Content:

- trust × capability model
- T0 / T1 / T2 / T3
- `agentd`
- `shrek-policy`
- `gatekeeperd`
- network capability model
- immutable image / boot trust chain
- Swamp / filesystem intelligence
- semantic authority invariant
- provenance model

### Level 3 — Contributor / implementation

For someone asking:

> I want to modify T2. What do I need to know before I touch it?

Content:

- implementation files
- design invariants
- known assumptions
- relevant tests
- acceptance gates
- supply artifacts
- related ADRs
- rejected approaches
- debugging notes that became lasting engineering lessons

## Docs organization

Possible structure:

```text
docs/
├── overview/
├── architecture/
├── security/
├── isolation/
├── networking/
├── filesystem-intelligence/
├── supply-chain/
├── development/
├── decisions/
├── lessons/
└── roadmap/
```

## Two audiences

### User-facing documentation

- What is Shrek OS?
- Why would I use it?
- Installation
- Desktop
- Donkey
- Permissions
- Running agents
- Security model in plain language
- FAQ

### Developer / architecture documentation

- boot chain
- image model
- trust classes
- capability model
- isolation tiers
- gatekeeperd
- agentd
- shrek-policy
- Swamp
- egress plane
- supply chain
- testing methodology
- design decisions and invariants

The user should not need to understand `KVM_CREATE_VM`.

The contributor working on T2 should be able to trace every relevant assumption.

## Graphify role

Graphify should help answer:

```text
Where is this concept implemented?
What imports / calls / refers to it?
Which files belong to the same subsystem?
Which docs mention the same concept?
Which tests relate to it?
```

The graph should guide selective source inspection.

It should not replace canonical source verification.

## Private memory role

Private maintainer memories may be used as an authoring reference for:

- reconstructing why a choice was made
- recovering rejected hypotheses
- identifying important lessons
- drafting ADRs
- remembering bugs that shaped architecture

Only reviewed conclusions become public documentation.

Private memory itself is not part of the FOSS artifact.

## Timing

Suggested milestone:

```text
finish / stabilize core Phase 5 security substrate
        ↓
freeze Architecture v0.1
        ↓
Graphify repository
        ↓
build first developer docs site
        ↓
continue desktop / higher-level work
        ↓
keep graph + docs evolving with code
```

Do not wait until the project is "finished."

The longer undocumented architectural relationships remain only in the maintainer's head, the harder they become to reconstruct accurately.

## Possible future dogfood path

The Shrek repository itself can become an early structured corpus for Swamp / Donkey.

Example:

```text
Donkey:
"Why is T2 networking deferred?"

        ↓

project graph / authorized corpus

        ↓

T2
→ networking
→ deferred capability
→ relevant architecture doc
→ implementation status
```

This would exercise project intelligence on a real complex codebase before broader filesystem indexing.
