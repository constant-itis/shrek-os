# Shrek OS Project Notes

These files were distilled from the August 18, 2026 design discussion for later incorporation into the Shrek OS repository.

## Files

- `00-shrekos-project-thesis.md` — core thesis, audience, and concise pitch
- `01-agent-security-model.md` — advisory-vs-enforced policy and agent security posture
- `02-foss-and-open-engineering.md` — FOSS philosophy and open engineering rationale
- `03-project-intelligence-and-ai-collaboration.md` — shared code graph / AI-assisted FOSS development concept
- `04-docs-site-plan.md` — future documentation-site structure and graph-assisted workflow
- `05-elevator-pitch-and-faq-seeds.md` — pitch language, skeptical FAQ seeds, and demo concept

These are working project artifacts, not canonical architecture documents yet. Review against the current repository before promoting statements into authoritative docs.
