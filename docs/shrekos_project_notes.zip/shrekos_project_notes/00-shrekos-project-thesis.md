# Shrek OS — Project Thesis

## One-line thesis

**Shrek OS is an agent-native Linux system for safely giving AI real autonomy on your computer without giving it your whole computer.**

## Core premise

Large language models are useful enough to act directly on computers, but they are not deterministic enough to enforce their own permissions.

Modern AI development tools are often constrained with natural-language instructions:

- stay inside this repository
- do not read private files
- do not upload credentials
- ask before modifying production
- only use approved services
- do not execute untrusted code

Those instructions are useful, and modern models follow them well enough to make agentic development practical.

But **"usually follows the rule" is not a security boundary**.

An agent can occasionally:

- fail to load an instruction file
- omit or forget a remembered constraint
- misunderstand scope
- follow conflicting context
- react incorrectly to prompt injection
- make the wrong tool call
- execute code whose behavior it did not predict

For workflow guidance, occasional failure may be tolerable.

For access control, it is not.

Shrek therefore separates two questions:

> **What should the agent do?**

from:

> **What is the agent physically capable of doing?**

Human-language instructions remain useful for intent, workflow, style, conventions, and task behavior.

Authority belongs underneath the model.

## Core separation

```text
Human language
    ↓
intent / workflow / behavior

Machine-enforced policy
    ↓
filesystem authority
network authority
execution authority
resource authority
isolation level
```

Or more simply:

> **Human language defines intent. Machine-enforced capabilities define authority.**

## Security posture

Shrek does not assume that AI is constantly disobedient or malicious.

It assumes AI is **probabilistic and fallible**.

If an agent follows every instruction perfectly, the hard security boundary may never be exercised.

If it makes one mistake six months later, the desired outcome is boring:

```text
agent attempts forbidden action
        ↓
kernel / sandbox / policy says no
        ↓
work continues or fails safely
```

The model does not need to be malicious.

It only needs to be capable of making a mistake.

This is the same reason conventional software is sandboxed even when its developers are trusted.

## Intended audience

The initial audience is people already moving toward AI-heavy development:

- developers using Claude Code, Codex, Gemini CLI, Cursor, local agents, or similar tools
- Linux users letting AI edit repositories and run commands
- people exposing project files, documentation, terminals, and build systems to agents
- local-AI users building persistent assistants
- developers running increasingly autonomous workflows
- technical users who want AI capability without granting an entire login session

Shrek is not primarily "Linux with a chatbot."

It is Linux designed around the fact that increasingly autonomous software is becoming part of the normal user session.

## The desired user experience

A user should eventually be able to say:

```text
Fix this repository.
```

and have the system derive something like:

```text
workload trust: untrusted
isolation floor: T2

filesystem:
    this repository      read/write
    everything else      absent

network:
    github-https         allowed
    everything else      denied

resources:
    bounded memory
    bounded process count
```

The user should not need to understand Landlock, namespaces, nftables, gVisor, or microVMs.

Those are implementation details.

## Short pitch

**Shrek OS is Linux for people who are increasingly letting AI work directly on their computers. Natural-language rules still tell the agent what it should do, but the operating system decides what it can do. Filesystem access, network access, execution authority, and isolation are granted explicitly and enforced below the model, so an occasional forgotten rule, prompt injection, or bad tool call does not automatically become a machine-wide security failure.**
